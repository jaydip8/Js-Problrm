import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule,Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { OrdersComponent } from './orders/orders.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardviewComponent } from './cardview/cardview.component';
import { ListviewComponent } from './listview/listview.component';
import { MapviewComponent } from './mapview/mapview.component';
import { NewcustomerComponent } from './newcustomer/newcustomer.component';

const appRoutes: Routes=[
  {path:'customer',component:CustomerComponent},
  {path:'orders',component:OrdersComponent},
  {path:'about',component:AboutComponent},
  {path:'login',component:LoginComponent},
  {path:'cardview',component:CardviewComponent},
  {path:'listview',component:ListviewComponent},
  {path:'mapview',component:MapviewComponent},
  {path:'newcustomer',component:NewcustomerComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    OrdersComponent,
    AboutComponent,
    LoginComponent,
    CardviewComponent,
    ListviewComponent,
    MapviewComponent,
    NewcustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
